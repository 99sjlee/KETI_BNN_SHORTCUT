#ifndef __ERVP_AIOIF_H__
#define __ERVP_AIOIF_H__

#include <stdint.h>
#include "ervp_external_peri_group_memorymap.h"

void aio_set_type(unsigned int index, unsigned int type);

#endif
