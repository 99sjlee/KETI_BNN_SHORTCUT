#ifndef _H_ADV7619_H_
#define _H_ADV7619_H_


void adv7619_init_ycbcr(void);
void adv7619_init_ycbcr_4k(void);


#endif