#include "OledChar.h"
#include "ervp_oledbw_printf.h"

//static int col = 0;
//static int row = 0;

void oledbw_putc(char c)
{
}
